/** Automatically generated file. DO NOT MODIFY */
package com.refresh.pos;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}