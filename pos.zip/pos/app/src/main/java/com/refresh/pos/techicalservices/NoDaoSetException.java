package com.refresh.pos.techicalservices;

public class NoDaoSetException extends Exception {

	private static final long serialVersionUID = 1L;
	
}
